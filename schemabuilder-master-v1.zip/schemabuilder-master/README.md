## Schema Builder

1. Establish connection with Teiid Server.
2. Fetch Database Meta.
3. Create GraphQL Object of each entries.