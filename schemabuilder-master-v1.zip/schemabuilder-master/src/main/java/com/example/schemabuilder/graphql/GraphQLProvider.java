package com.example.schemabuilder.graphql;

import com.example.schemabuilder.service.Metadata;
import com.google.common.base.Charsets;
import com.google.common.io.Resources;
import graphql.GraphQL;
import graphql.execution.SubscriptionExecutionStrategy;
import graphql.schema.GraphQLObjectType;
import graphql.schema.GraphQLSchema;
import graphql.schema.idl.RuntimeWiring;
import graphql.schema.idl.SchemaGenerator;
import graphql.schema.idl.SchemaParser;
import graphql.schema.idl.TypeDefinitionRegistry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Collectors;

import static graphql.schema.idl.TypeRuntimeWiring.newTypeWiring;

@Component
public class GraphQLProvider {
	@Value("classpath:schema.graphqls")
    Resource resource;

    @Autowired
    GraphQLDataFetchers graphQLDataFetchers;
    @Autowired
    Metadata metadata;

    private GraphQL graphQL;
    
    public String sdl = "";

    @PostConstruct
    public void init() throws Exception {
        File file = resource.getFile();
        System.out.println("file.toPath().toAbsolutePath():" + file.toPath().toAbsolutePath());
        String sdlQuery = String.join("\n ", Files.lines(file.toPath().toAbsolutePath(), StandardCharsets.UTF_8).collect(Collectors.toList())) + "\n";
        
        //URL url = Resources.getResource("schema.graphqls");
        //String sdlQuery = Resources.toString(url, Charsets.UTF_8);
        //String sdl1 = metadata.createSchemaFromMap();
        String sdlBook = metadata.createSchema("aluo", "book", "Book");
        String sdlAuthor = metadata.createSchema("aluo", "author", "Author");
        String sdlCustomer = metadata.createSchema("aluo", "customer", "Customer");
        sdl = sdlQuery + sdlBook + sdlAuthor + sdlCustomer;
        GraphQLSchema graphQLSchema = buildSchema(sdl);
        System.out.println(sdl);
        this.graphQL = GraphQL
        		.newGraphQL(graphQLSchema)
        		.subscriptionExecutionStrategy(new SubscriptionExecutionStrategy())
        		.build();
        /*
        GraphQLObjectType type = graphQLSchema.getQueryType();
        type.getFieldDefinitions().forEach(f->{
        	System.out.printf("filed Name:%s ; field type: %s %n",f.getName(), f.getType());
        	});
        
        type = graphQLSchema.getObjectType("Customer");
        
        type.getFieldDefinitions().forEach(f->{
        	System.out.printf("filed Name:%s ; field type: %s %n",f.getName(), f.getType());
        	});
        */	
    }

    private GraphQLSchema buildSchema(String sdl) {
        TypeDefinitionRegistry typeRegistry = new SchemaParser().parse(sdl);
        RuntimeWiring runtimeWiring = buildWiring();
        SchemaGenerator schemaGenerator = new SchemaGenerator();
        
        return schemaGenerator.makeExecutableSchema(typeRegistry, runtimeWiring);
    }

    /*
    private RuntimeWiring buildWiring() {
        return RuntimeWiring.newRuntimeWiring()
                .type(newTypeWiring("Query")
                        .dataFetcher("bookById", graphQLDataFetchers.getBookByIdDataFetcher()))
                .type(newTypeWiring("Query")
                        .dataFetcher("greeting", graphQLDataFetchers.getGreetingFetcher()))
                .type(newTypeWiring("Query")
                        .dataFetcher("customers", graphQLDataFetchers.getCustomersFetcher()))                
                .type(newTypeWiring("Book")
                        .dataFetcher("author", graphQLDataFetchers.getAuthorDataFetcher())
                        // This line is new: we need to register the additional DataFetcher
                        .dataFetcher("pageCount", graphQLDataFetchers.getPageCountDataFetcher()))
                .type(newTypeWiring("Query")
                        .dataFetcher("getData", graphQLDataFetchers.getResponseDataFetcher())) 
                .type(newTypeWiring("Query")
                        .dataFetcher("stockDetail", graphQLDataFetchers.getStockDetailFetcher())) 
                .type(newTypeWiring("Subscription")
                        .dataFetcher("stockPrice", graphQLDataFetchers.getStockPriceFetcher())) 
                .type(newTypeWiring("Subscription")
                        .dataFetcher("stockQuotes", graphQLDataFetchers.stockQuotesSubscriptionFetcher()))
                .build();
    }*/

    
    private RuntimeWiring buildWiring() {
        return RuntimeWiring.newRuntimeWiring()
                .type(newTypeWiring("Query")
                        .dataFetcher("getData", graphQLDataFetchers.getResponseDataFetcher())) 
                .type(newTypeWiring("Query")
                        .dataFetcher("getDataByFields", graphQLDataFetchers.getResponseDataByFieldsFetcher())) 
                .type(newTypeWiring("Subscription")
                        .dataFetcher("stockPrice", graphQLDataFetchers.getStockPriceFetcher())) 
                .type(newTypeWiring("Subscription")
                        .dataFetcher("stockQuotes", graphQLDataFetchers.stockQuotesSubscriptionFetcher()))
                .build();
    }
    


    @Bean
    public GraphQL graphQL() {
        return graphQL;
    }

}
