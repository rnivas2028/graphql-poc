package com.example.schemabuilder.service;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

@Repository
public class BaseRepository {
	@Autowired
	protected JdbcTemplate jdbcTemplate;
	//@Autowired
	//private Metadata metadata;
	
	public List<Map<String, Object>> findAll(List<String> columnNames, String table) throws Exception {
		return findAll(columnNames, table, 0, 0);
	}
	public List<Map<String, Object>> findAll(List<String> columnNames, String table, int start, int limit) throws Exception {
		return findAll(columnNames, table, 0, 0, null);
	}
	public List<Map<String, Object>> findAll(List<String> columnNames, String table, int start, int limit, String clause) throws Exception {
		//List<String> columns = metadata.getColumns("customer1");
		String selectedCoulmns = String.join(", ", columnNames); 		
		String sql = "SELECT " + selectedCoulmns  + " FROM " + table;
		if (clause != null ) {
			sql += " where " + clause;
		}
		if (limit > 0) {
			sql = sql + " limit " + limit + " offset " + (start-1);
		}
		System.out.println("Repository::findAll - " + sql);
		//List<String> columns = new ArrayList<String>();
		List<Map<String, Object>> list = jdbcTemplate.query(sql, new RowMapper<Map<String, Object>>() {
	        public Map<String, Object> mapRow(ResultSet rs, int rowNum) throws SQLException {
	        	/*if (columns.isEmpty()) {
	        	  ResultSetMetaData rsmd = rs.getMetaData();
	        	  int columnCount = rsmd.getColumnCount();
	        	  for (int i=1; i<=columnCount; i++) {
	        		  columns.add(rsmd.getColumnName(i));
	        	  }
	        	}*/
	        	
	        	Map<String, Object> map = new HashMap<String, Object>();
	        	columnNames.forEach(col -> {
						try {
							Object res = rs.getObject(col);
							map.put(col, res);
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
	        	});
	            return map;
	        }
	    });
		return list;
	}	

	
}
