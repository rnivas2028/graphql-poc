package com.example.schemabuilder.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

@Repository
public class CustomerRepository extends BaseRepository{
	public List<Map<String, Object>> findAll(List<String> columnNames) throws Exception {
		return super.findAll(columnNames, "customer");
	}
	public List<Map<String, Object>> findAll(List<String> columnNames, int start, int limit) throws Exception {
		return super.findAll(columnNames, "customer", start, limit);
	}	
	public List<Map<String, Object>> findAll(List<String> columnNames, int start, int limit, String clause) throws Exception {
		return super.findAll(columnNames, "customer", start, limit, clause);
	}	
		
}
