package com.example.schemabuilder.graphql;

import com.example.schemabuilder.model.ResponseData;
import com.example.schemabuilder.model.StockDetail;
import com.example.schemabuilder.model.StockPrice;
import com.example.schemabuilder.service.AuthorRepository;
import com.example.schemabuilder.service.BaseRepository;
import com.example.schemabuilder.service.BookRepository;
import com.example.schemabuilder.service.CustomerRepository;
import com.example.schemabuilder.service.Metadata;
import com.example.schemabuilder.stockupdate.StockTickerPublisher;
import com.google.common.collect.ImmutableMap;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;
import graphql.schema.DataFetchingFieldSelectionSet;
import graphql.schema.GraphQLEnumType;
import graphql.schema.SelectedField;
import reactor.core.publisher.Flux;

import org.apache.commons.lang3.StringUtils;
import org.reactivestreams.Publisher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.lang.reflect.Field;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;

import static graphql.schema.GraphQLEnumType.newEnum;


@Component
public class GraphQLDataFetchers {
	
	@Autowired
	private BaseRepository baseRepository;
	//@Autowired
	//private AuthorRepository authorRepository;
	//@Autowired
	//private CustomerRepository customerRepository;
	
	@Autowired
    private Metadata metaData;
	@Autowired
	private MockMemData mockMemData;
	
    private final static StockTickerPublisher STOCK_TICKER_PUBLISHER = new StockTickerPublisher();

    
	private List<Map<String, Object>> getAllData(String tableName, DataFetchingFieldSelectionSet selectionSet, String cache, int first, int limit) {
		return getAllData(tableName, selectionSet, cache, first, limit, null);
	}	
	private List<Map<String, Object>> getAllData(String tableName, DataFetchingFieldSelectionSet selectionSet, String cache, int first, int limit, String clause) {		
		List<Map<String, Object>> dbList = new ArrayList<Map<String, Object>>();
		if (cache!=null && cache.equals("IGNITE")) {
			List<String> columnNames = getColumnNames(selectionSet);
		    try {
				dbList = baseRepository.findAll(columnNames, tableName, first, limit, clause);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {	
		    dbList = mockMemData.getMockData(tableName).stream().collect(Collectors.toList());
		}
		return dbList;
	}
	
    private List<String> getColumnNames(DataFetchingFieldSelectionSet selectionSet) {
    	List<String> columnNames = new ArrayList<String>();
    	selectionSet.getFields().forEach(f->columnNames.add(f.getName()));
    	return columnNames;
    }
    
    
    public DataFetcher getResponseDataFetcher() {
        return dataFetchingEnvironment -> {        	
        	DataFetchingFieldSelectionSet selectionSet = dataFetchingEnvironment.getSelectionSet();
        	selectionSet.getFields().forEach(f->System.out.printf("filed Name:%s ; qualify name: %s %n",f.getName(), f.getQualifiedName()));
            return createResponseData(dataFetchingEnvironment).getDataMap();
        };
    }    
    private ResponseData createResponseData(DataFetchingEnvironment dataFetchingEnvironment){
    	String cache = dataFetchingEnvironment.getArgument("cacheName");
    	int first = dataFetchingEnvironment.getArgument("first");
    	int limit = dataFetchingEnvironment.getArgument("limit");
    	DataFetchingFieldSelectionSet selectionSet = dataFetchingEnvironment.getSelectionSet();
    	
    	ResponseData responseData = new ResponseData();
    	
    	for (SelectedField f : selectionSet.getFields()) {
    		
    		if (f.getQualifiedName().equals(f.getName())) {
    		    List<Map<String, Object>> dbList = getAllData(f.getName(), f.getSelectionSet(), cache, first, limit);
    		    setResponseDataField(responseData, f.getName(), dbList);
    		}
    	}
    	
    	return responseData;
    }
    
    public DataFetcher getResponseDataByFieldsFetcher() {
        return dataFetchingEnvironment -> {        	
        	DataFetchingFieldSelectionSet selectionSet = dataFetchingEnvironment.getSelectionSet();
        	//selectionSet.getFields().forEach(f->System.out.printf("filed Name:%s ; qualify name: %s %n",f.getName(), f.getQualifiedName()));
            return createResponseDataByFields(dataFetchingEnvironment).getDataMap();
        };
    }    
    private ResponseData createResponseDataByFields(DataFetchingEnvironment dataFetchingEnvironment){
    	String cache = "IGNITE";
    	String clause = dataFetchingEnvironment.getArgument("fieldName");
    	String[] fields = StringUtils.split("=");
    	String field = "";
    	if (fields.length > 1) {
    		field = fields[0];
    	}
    	
    	int first = dataFetchingEnvironment.getArgument("first");
    	int limit = dataFetchingEnvironment.getArgument("limit");
    	DataFetchingFieldSelectionSet selectionSet = dataFetchingEnvironment.getSelectionSet();
    	
    	ResponseData responseData = new ResponseData();
    	
    	for (SelectedField f : selectionSet.getFields()) {
    		if (f.getQualifiedName().equals(f.getName())) {
    	  	  List<Map<String, Object>> dbList = getAllData(f.getName(), f.getSelectionSet(), cache, first, limit);
    		  setResponseDataField(responseData, f.getName(), dbList);
    		}
    	}
    	
    	return responseData;
    }
    
    private void setResponseDataField(ResponseData data, String field, List<Map<String, Object>> value) {
    	data.putData(field, value);
		/*try {
		   Field dataField = data.getClass().getDeclaredField(field);
	        dataField.setAccessible(true);
	        dataField.set(data, value);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
    }

    
    
    public DataFetcher<Publisher<StockPrice>> getStockPriceFetcher() {
        return dataFetchingEnvironment -> {
            String symbol = dataFetchingEnvironment.getArgument("symbol");
            return stockPrice(symbol);
        };
    }    
    public Publisher<StockPrice> stockPrice(String symbol) {
        Random random = new Random();
        return Flux
        		//.range(1, 10).delayElements(Duration.ofSeconds(1))
        		.interval(Duration.ofSeconds(1))
                .map(num -> new StockPrice(symbol, random.nextDouble(), LocalDateTime.now()));
    }
    public DataFetcher getStockDetailFetcher() {
        return dataFetchingEnvironment -> {
            String symbol = dataFetchingEnvironment.getArgument("symbol");
            return stockDetail(symbol);
        };
    }
    
    public StockDetail stockDetail(String symbol) {
        return new StockDetail(symbol, "name", 2000l);
     }
    
    
    public DataFetcher stockQuotesSubscriptionFetcher() {
        return environment -> {
            List<String> arg = environment.getArgument("stockCodes");
            List<String> stockCodesFilter = arg == null ? Collections.emptyList() : arg;
            if (stockCodesFilter.isEmpty()) {
                return STOCK_TICKER_PUBLISHER.getPublisher();
            } else {
                return STOCK_TICKER_PUBLISHER.getPublisher(stockCodesFilter);
            }
        };
    }    
}
