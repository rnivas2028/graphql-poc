package com.example.schemabuilder.query;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.coxautodev.graphql.tools.GraphQLQueryResolver;
import com.example.schemabuilder.service.CustomerRepository;

import graphql.schema.DataFetchingEnvironment;
import graphql.schema.DataFetchingFieldSelectionSet;

//@Component
public class CustomerQueryResolver implements GraphQLQueryResolver{
	@Autowired
	private CustomerRepository customerRepository;

    public List<Map<String, Object>> getCustomers(@Autowired DataFetchingEnvironment environment) throws Exception {
        return this.customerRepository.findAll(getColumnNames(environment));
    }
    
    public String getGreeting() {
    	return "Hello";
    }
    
    private List<String> getColumnNames(DataFetchingEnvironment dataFetchingEnvironment) {
    	DataFetchingFieldSelectionSet selectionSet = dataFetchingEnvironment.getSelectionSet();
    	List<String> columnNames = new ArrayList<String>();
    	selectionSet.getFields().forEach(f->columnNames.add(f.getName()));
    	return columnNames;
    }

}
